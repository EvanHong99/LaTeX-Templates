includetests = {
  "06-*",
  "07-*",
  "09-*",
}
excludetests = {}

checkruns = 2
