testfiledir = "testfiles/01-cover"
testsuppdir = testfiledir .. "/support"

includetests = {"*"}
excludetests = {}
